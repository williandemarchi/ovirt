#!/bin/bash

export TERM=linux
export TERMINFO=/etc/terminfo

/root/restart_backup_vm_expect.sh