# oVirtSimpleBackup - Debian 8 ovirt-guest-agent Setup Script

#### Outline

This script just simplifies the install of the ovirt-guest-agent on a fresh install of Debian 8 (Jessie)

#### Usage
    ```
    ./debian8_ovirt-guest-agent_install.sh
    ```

#### Author

You can reach zipur on the IRC SERVER irc.oftc.net CHANNEL #ovirt

http://zipur.ca

aka (Preston Lord)

