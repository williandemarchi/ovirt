# oVirtSimpleBackup - WebGUI 

Moved WebGUI to root of project here: 

https://github.com/zipurman/oVIRT_Simple_Backup/
