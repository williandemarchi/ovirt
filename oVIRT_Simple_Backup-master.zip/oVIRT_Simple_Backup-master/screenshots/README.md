# oVirtSimpleBackup - WebGUI

https://github.com/zipurman/oVIRT_Simple_Backup/

### Screenshots

![ ](SS.0.6.14.01.png?raw=true)

![ ](SS.0.6.14.02.png?raw=true)

![ ](SS.0.6.14.03.png?raw=true)

![ ](SS.0.6.14.04.png?raw=true)

![ ](SS.0.6.14.05.png?raw=true)

![ ](SS.0.6.14.06.png?raw=true)

![ ](SS.0.6.14.07.png?raw=true)

![ ](SS.0.6.14.08.png?raw=true)

![ ](SS.0.6.14.09.png?raw=true)

![ ](SS.0.6.14.10.png?raw=true)
