#### Contributing

If you would like to contribute, you can create a fork of the project and then once you have coded your chnages and **tested them**, you can issue a pull request and I will review.

Thanks

Zip