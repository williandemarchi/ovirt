</div>
<?php

?>
<div id="sb_foot">
    Created By <a style="color: #ddd;" href="https://github.com/zipurman/" target="_blank">zipur</a> for anyone who has the need ;)
</div>
</body>
</html>